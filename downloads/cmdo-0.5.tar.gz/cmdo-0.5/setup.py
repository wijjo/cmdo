#!/usr/bin/env python

"""Setup script for the cmdo (commando) module distribution."""

import os, os.path
from glob import glob
from distutils.core import setup, Command
from distutils.command.install import install

version = os.popen('test/cmdo version').readline().strip().split(' ')[1]
print 'version=%s' % version

class generate(Command):
    description = "Generate documentation"
    user_options = []
    def initialize_options(self):
        pass
    def finalize_options(self):
        pass
    def run(self):
        os.system('test/cmdo help development output=DEVELOPMENT')
        os.system('test/cmdo help readme output=README')
        os.system('test/cmdo help install output=INSTALL')
        os.system('test/cmdo help development format=html output=development.html')
        os.system('test/cmdo help readme format=html output=readme.html')
        os.system('test/cmdo help install format=html output=install.html')
        os.system('test/cmdo help bash_completion_script output=etc/bash_completion.d/cmdo plain="yes"')
        os.system('test/ardo help bash_completion_script output=etc/bash_completion.d/ardo plain="yes"')

install.sub_commands.append(('generate', None))

setup(
    name = 'cmdo',
    version = version,
    description = 'module to ease the creation of command-driven scripts',
    author = 'Steve Cooper',
    author_email = "steve@wijjo.com",
    url = "http://wijjo.com/cmdo/",
    packages = ['cmdo'],
    scripts = ['bin/cmdo', 'bin/ardo'],
    data_files = [
        ('lib/cmdo/cmdo.d', glob(os.path.join('cmdo.d', '*.cmdo'))),
        ('lib/cmdo/cmdo.d', glob(os.path.join('cmdo.d', '*.cmdocore'))),
        ('lib/cmdo/cmdo.d', glob(os.path.join('cmdo.d', '*.cmdodoc'))),
        ('lib/ardo/ardo.d', glob(os.path.join('ardo.d', '*.cmdo'))),
        ('lib/ardo/ardo.d', glob(os.path.join('ardo.d', '*.cmdocore'))),
        ('lib/ardo/ardo.d', glob(os.path.join('ardo.d', '*.cmdodoc'))),
        ('/etc/bash_completion.d', glob(os.path.join('etc', 'bash_completion.d', '*'))),
    ],
    cmdclass = {
        'generate': generate
    },
)
