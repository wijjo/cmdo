#===============================================================================
#===============================================================================
# System utility functions
#
# Author Steve Cooper   steve@wijjo.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#===============================================================================
#===============================================================================

import sys
import os
import re
from glob import glob
import os.path
import shlex
import select

#===============================================================================

def findProgram(*names):
    '''Returns first occurance of program name(s) in the system path.'''
    for dir in os.environ['PATH'].split(':'):
        for name in names:
            name = os.path.join(dir, name)
            if os.path.exists(name):
                return name
    return None

#===============================================================================

def getVersionedPath(path, suffix):
    (base, ext) = os.path.splitext(path)
    reStripVersion = re.compile('(.*)-%s(-[0-9]*)?' % suffix)
    m = reStripVersion.match(base)
    if m:
        base = m.group(1)
    path = '%s-%s%s' % (base, suffix, ext)
    if not os.path.exists(path):
        return path
    n = 1
    for chk in glob('%s-%s-[0-9]*%s' % (base, suffix, ext)):
        i = int(os.path.splitext(chk)[0].split('-')[-1])
        if i > n:
            n = i
    suffix2 = '%s-%d' % (suffix, n+1)
    return '%s-%s%s' % (base, suffix2, ext)

#===============================================================================

def spawn(command):
    '''Spawns a command process.  Returns the process ID (PID).'''
    (fin, fout) = os.pipe()
    pid = os.fork()
    if pid == 0:
        # Child
        pid = os.fork()
        if pid != 0:
            os._exit(0)
        # Child of child
        os.write(fout, '%d' % os.getpid())
        try:
            a = shlex.split(command)
            os.execvp(a[0], a)
        except OSError, e:
            sys.stderr.write('Failed to spawn "%s"\n    %s\n' % (command, e))
        os._exit(1)
    else:
        ready = select.select([fin], [], [])
        os.waitpid(pid, 0)
        if ready[0] and ready[0][0] == fin:
            pid = int(os.read(fin, 99).strip())
        else:
            sys.stderr.write('Failed to get pid for "%s"\n' % command)
            pid = 0
        os.close(fin)
        os.close(fout)
        return pid
